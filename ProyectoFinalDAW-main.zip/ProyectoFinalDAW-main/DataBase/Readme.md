# BASE DE DATOS
Contiene tres ficheros:
- Estructura de la BBDD en formato .sql
- Datos de prueba del proyecto en formato .sql
- Listado de consultas en formato .txt

