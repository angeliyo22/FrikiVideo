# Imagenes

Contiene imágenes auxiliares del documento raiz README.md